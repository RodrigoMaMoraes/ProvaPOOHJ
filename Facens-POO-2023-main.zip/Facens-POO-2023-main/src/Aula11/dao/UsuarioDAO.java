package Aula11.dao;

import Aula11.entity.Usuario;


public class UsuarioDAO extends GenericDAO<Usuario>{

    public UsuarioDAO() {
    }
}
