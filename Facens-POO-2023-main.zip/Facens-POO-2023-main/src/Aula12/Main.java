package Aula12;

import Aula9_Heranca.Animal;
import Aula9_Heranca.Cachorro;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        //Animal animal = new Animal("Xodo", 10);
        
        Cachorro dog = new Cachorro("Xodo", 10);
        dog.falar();
        
        ArrayList<Animal> arAnimais;
        
        
    }
}
