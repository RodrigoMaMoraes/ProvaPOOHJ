
package Aula12;

import Aula9_Heranca.Animal;


public class Morcego extends Animal{

    public Morcego(String nome, int idade) {
        super(nome, idade);
    }
    
    @Override
    public void falar() {
       
    }
}
