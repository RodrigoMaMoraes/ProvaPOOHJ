package Aula9_Heranca;

public class Capivara extends Animal{

    public Capivara(String nome, int idade) {
        super(nome, idade);
    }

    @Override
    public void falar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
